This program mainly implements the MFEA-GHS which was described in our paper:

A Hybrid of Genetic Transform and Hyper-rectangle Search Strategies for Evolutionary Multi-tasking

***********************************************************************************************************************
1.The code was implemented in matlab. 
2.Note that this trial version of the MO-MFEA-GHS handles upto 2 "continuous" multi-objective multi-factorial optimization.
3 The test suite contain 9 multi-objective multi-factorial problems and can be download in http://www.bdsc.site/websites/MTO/index.html.	
4.Users can run the "MAIN.m" function to execute the algorithm.Note that some parameters can be tuned in "main.m".
After testing, the result(IGD+) at every moment will be stored in a new file "result.mat".

*********************************************************************************************************************** 

Finally, it should be noted that this code can be used only for non-commercial purposes. 
We'd appreciate your acknowledgement if you use the code. 

For any problem concerning the code, please feel free to contact ZhangJian (email: roykin_1002@163.com).
