clear all
rmp=0.7; % Random mating probability
gen = 1000; % Maximum Number of generations
muc = 20; % Distribution Index of SBX crossover operator
mum = 20; % Distribution Index of Polynomial Mutation operator
pc = 0.9; % Probability that certain pair of variables are swapped (uniform crossover-like) during SBX crossover. Change to prob_swap = 0.5 for enhanced global search at the cost of high chromosome disruption.
pop1=100; % Population size for task 1
pop2=100; % Population size for task 2
reps = 1;
for index =1:9
    Task = benchmark(index);
    data(index) = MOMFEA_GHS(Task,pop1,pop2,rmp,gen,muc,mum,pc,reps,index); 
end
save('result','data');