function data =MOMFEA_GHS(Task,pop1,pop2,rmp,gen,muc,mum,pc,reps,index)  
    tic
    pop = pop1+pop2;
    dim1=length(Task.L1);
    dim2=length(Task.L2);
    dim=max([dim1,dim2]);
    for rep = 1:reps
        bestobj(1) = 9999999999999999999;
        bestobj(2) = 9999999999999999999;
        M1 = ones(1,dim);
        M2 = ones(1,dim);
        for i=1:pop
            population(i)=Chromosome;
            population(i)=initialize(population(i),dim);
            if i<=pop1
                population(i).skill_factor=1;
            else
                population(i).skill_factor=2;
            end
        end    
        for i=1:pop
            population(i)=evaluate(population(i),Task,dim1,dim2);
        end        
        [max_T1,max_T2,min_T1,min_T2] = cal_max_min(population);
        population_T1=population([population.skill_factor]==1);
        population_T2=population([population.skill_factor]==2);
        no_of_objs_T1 = length(population_T1(1).objs_T1);
        no_of_objs_T2 = length(population_T2(1).objs_T2);
        for generation=1:gen
            %Randomly select parents
            randlist = randperm(pop);
            population = population(randlist);
            generation
            count=1;
            if mod(generation,2) == 0
                a = 0;
            else
                a = 1;
            end
            for i=1:2:pop 
                child(count)=Chromosome;
                child(count+1)=Chromosome;
                p1=i;
                p2=i+1;
                k = 0.5 + 1*rand(1);
                if population(p1).skill_factor==population(p2).skill_factor
                    if rand(1) > a
                        child(count).rnvec=Evolve.crossover(population(p1).rnvec,population(p2).rnvec,muc,dim,pc);
                        child(count+1).rnvec = 1 - child(count).rnvec;
                    elseif population(p1).skill_factor == 1
                        child(count).rnvec=Evolve.crossover(population(p1).rnvec,population(p2).rnvec,muc,dim,pc);
                        child(count+1).rnvec = k*(max_T1+min_T1) - child(count).rnvec;
                    else
                        child(count).rnvec=Evolve.crossover(population(p1).rnvec,population(p2).rnvec,muc,dim,pc);
                        child(count+1).rnvec = k*(max_T2+min_T2) - child(count).rnvec;
                    end    
                    child(count).rnvec = Evolve.mutate(child(count).rnvec,mum,dim,1/dim);
                    child(count+1).rnvec=Evolve.mutate(child(count+1).rnvec,mum,dim,1/dim);
                    child(count).skill_factor=population(p1).skill_factor;
                    child(count+1).skill_factor=population(p2).skill_factor;
                else
                    if rand(1)<rmp
                        if rand(1) > 0.5
                            if population(p1).skill_factor == 1 && population(p2).skill_factor == 2
                                tmp = population(p1);
                                tmp.rnvec = population(p1).rnvec .* M1;
                                tmp.rnvec(tmp.rnvec>1) = 1;
                                tmp.rnvec(tmp.rnvec<0) = 0;
                                child(count).rnvec = Evolve.crossover(tmp.rnvec,population(p2).rnvec,muc,dim,pc);
                                if rand(1) > a
                                    child(count+1).rnvec = 1 - child(count).rnvec;
                                else
                                    child(count+1).rnvec = k*(max_T2+min_T2) - child(count).rnvec;
                                end
                            else
                                tmp = population(p2);
                                tmp.rnvec = population(p2).rnvec .* M1;
                                tmp.rnvec(tmp.rnvec>1) = 1;
                                tmp.rnvec(tmp.rnvec<0) = 0;
                                child(count).rnvec = Evolve.crossover(population(p1).rnvec,tmp.rnvec,muc,dim,pc);
                                if rand(1) > a
                                    child(count+1).rnvec = 1 - child(count).rnvec;
                                else
                                    child(count+1).rnvec = k*(max_T2+min_T2) - child(count).rnvec;
                                end
                            end
                        else
                            if population(p1).skill_factor == 2 && population(p2).skill_factor == 1
                                tmp = population(p1);
                                tmp.rnvec = population(p1).rnvec .* M2;
                                tmp.rnvec(tmp.rnvec>1) = 1;
                                tmp.rnvec(tmp.rnvec<0) = 0;
                                child(count).rnvec= Evolve.crossover(tmp.rnvec,population(p2).rnvec,muc,dim,pc); 
                                if rand(1) > a
                                    child(count+1).rnvec = 1 - child(count).rnvec;
                                else
                                    child(count+1).rnvec = k*(max_T1+min_T1) - child(count).rnvec;
                                end
                            else
                                tmp = population(p2);
                                tmp.rnvec = population(p2).rnvec .* M2;
                                tmp.rnvec(tmp.rnvec>1) = 1;
                                tmp.rnvec(tmp.rnvec<0) = 0;
                                child(count).rnvec= Evolve.crossover(population(p1).rnvec,tmp.rnvec,muc,dim,pc);
                                 if rand(1) > a
                                   child(count+1).rnvec = 1 - child(count).rnvec;
                                else
                                    child(count+1).rnvec = k*(max_T1+min_T1) - child(count).rnvec;
                                end
                            end
                        end
                        child(count).skill_factor=round(rand(1))+1;
                        child(count+1).skill_factor=round(rand(1))+1;
                    else
                        child(count).rnvec = Evolve.mutate(population(p1).rnvec,mum,dim,1/dim);
                        child(count+1).rnvec=Evolve.mutate(population(p2).rnvec,mum,dim,1/dim);
                        child(count).skill_factor=population(p1).skill_factor;
                        child(count+1).skill_factor=population(p2).skill_factor;
                    end
                end
                child(count).rnvec(child(count).rnvec>1)=1;
                child(count).rnvec(child(count).rnvec<0)=0;
                child(count+1).rnvec(child(count+1).rnvec>1)=1;
                child(count+1).rnvec(child(count+1).rnvec<0)=0;
                count=count+2;
            end        
            for i=1:pop
                child(i)=evaluate(child(i),Task,dim1,dim2);
            end
            intpopulation(1:pop)=population;
            intpopulation(pop+1:2*pop)=child;
            intpopulation_T1=intpopulation([intpopulation.skill_factor]==1);
            intpopulation_T2=intpopulation([intpopulation.skill_factor]==2);
            pop_objs_T1=[];
            pop_objs_T2=[];
            for i=1:length(intpopulation_T1)
                pop_objs_T1(i,:) = intpopulation_T1(i).objs_T1;
            end
            [frontnumbers, FrontNO1,~] = NDSort(pop_objs_T1,inf);
            for i=1:length(intpopulation_T1)
                intpopulation_T1(i).front = FrontNO1(i);
            end
            [intpopulation_T1,~]=SolutionComparison.diversity(intpopulation_T1,frontnumbers,length(intpopulation_T1),no_of_objs_T1);
            for i=1:length(intpopulation_T2)
                pop_objs_T2(i,:) = intpopulation_T2(i).objs_T2;
            end
            [frontnumbers, FrontNO2,~] = NDSort(pop_objs_T2,inf);
            for i=1:length(intpopulation_T2)
                intpopulation_T2(i).front = FrontNO2(i);
            end
            [intpopulation_T2,~]=SolutionComparison.diversity(intpopulation_T2,frontnumbers,length(intpopulation_T2),no_of_objs_T2);
            
            %Select fittest individuals
            population(1:pop1) = intpopulation_T1(1:pop1);
            population(pop1+1:pop) = intpopulation_T2(1:pop2);   
            
            %Update mapping vector
            [M1,M2] = domain_ad(population);
            [max_T1,max_T2,min_T1,min_T2] = cal_max_min(population);
            
            % Convergence testing
            if index == 8 || index == 9
                T1_data = vec2mat([population(1:pop1).objs_T1],3);
                T2_data = vec2mat([population(pop1+1:pop).objs_T2],2);
            else
                T1_data = vec2mat([population(1:pop1).objs_T1],2);
                T2_data = vec2mat([population(pop1+1:pop).objs_T2],2);
            end
            t1_IGD = IGD_plus(T1_data,Task.type1);
            if t1_IGD<=bestobj(1)
                bestobj(1)=t1_IGD;
                store(1,generation)= t1_IGD;
            else
                store(1,generation)= store(1,generation-1);
            end
            t2_IGD = IGD_plus(T2_data,Task.type2);
            if t2_IGD<=bestobj(2)
                bestobj(2)=t2_IGD;
                store(2,generation)= t2_IGD;
            else
                store(2,generation)= store(2,generation-1);
            end
            
        end  
        IGD1(rep,:) = store(1,:);
        IGD2(rep,:) = store(2,:);
    end
    data.wall_clock_time = toc;
    data.IGD1 = IGD1;
    data.IGD2 = IGD2;
end