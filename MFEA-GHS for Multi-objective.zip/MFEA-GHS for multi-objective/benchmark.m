function Tasks = benchmark(index)
%BENCHMARK function
%   Input
%   - index: the index number of problem set
%   Output:
%   - Tasks: benchmark problem set
    switch(index)
        case 1  %CIHS
            Tasks.f1='CIHS_task_T1';
            % Assigning upper and lower bounds of search space of task 1
            Tasks.L1=-100*ones(1,50);
            Tasks.U1=100*ones(1,50);
            Tasks.L1(1)=0;
            Tasks.U1(1)=1;
            Tasks.type1 = 'circle';
            % Assigning upper and lower bounds of search space of task 2
            Tasks.f2='CIHS_task_T2';
            Tasks.L2=-100*ones(1,50);
            Tasks.U2=100*ones(1,50);
            Tasks.L2(1)=0;
            Tasks.U2(1)=1;
            Tasks.type2 = 'concave';
        case 2  %CIMS
            Tasks.f1='CIMS_task_T1';
            % Assigning upper and lower bounds of search space of task 1
            Tasks.L1=-5*ones(1,10);
            Tasks.U1=5*ones(1,10);
            Tasks.L1(1)=0;
            Tasks.U1(1)=1;
            Tasks.type1 = 'concave';
            Tasks.f2='CIMS_task_T2';    
            % Assigning upper and lower bounds of search space of task 2
            Tasks.L2=-5*ones(1,10);
            Tasks.U2=5*ones(1,10);
            Tasks.L2(1)=0;
            Tasks.U2(1)=1;
            Tasks.type2 = 'circle';
        case 3  %CILS
            Tasks.f1='CILS_task_T1';
            % Assigning upper and lower bounds of search space of task 1
            Tasks.L1=-2*ones(1,50);
            Tasks.U1=2*ones(1,50);
            Tasks.L1(1)=0;
            Tasks.U1(1)=1;
            Tasks.f2='CILS_task_T2';
            Tasks.type1 = 'circle';
            % Assigning upper and lower bounds of search space of task 2
            Tasks.L2=-1*ones(1,50);
            Tasks.U2=1*ones(1,50);
            Tasks.L2(1)=0;
            Tasks.U2(1)=1;
            Tasks.type2 = 'convex';
        case 4  %PIHS
            Tasks.f1='PIHS_task_T1';
            % Assigning upper and lower bounds of search space of task 1
            Tasks.L1=-100*ones(1,50);
            Tasks.U1=100*ones(1,50);
            Tasks.L1(1)=0;
            Tasks.U1(1)=1;
            Tasks.type1 = 'convex';
            Tasks.f2='PIHS_task_T2';
            % Assigning upper and lower bounds of search space of task 2
            Tasks.L2=-100*ones(1,50);
            Tasks.U2=100*ones(1,50);
            Tasks.L2(1)=0;
            Tasks.U2(1)=1;
            Tasks.type2 = 'convex';
        case 5  %PIMS
            Tasks.f1='PIMS_task_T1';
            % Assigning upper and lower bounds of search space of task 1
            Tasks.L1=0*ones(1,50);
            Tasks.U1=1*ones(1,50);
            Tasks.L1(1)=0;
            Tasks.U1(1)=1;
            Tasks.type1 = 'circle';
            Tasks.f2='PIMS_task_T2';
            % Assigning upper and lower bounds of search space of task 2
            Tasks.L2=-0*ones(1,50);
            Tasks.U2=1*ones(1,50);
            Tasks.L2(1)=0;
            Tasks.U2(1)=1;
            Tasks.type2 = 'concave';
        case 6  %PILS
            Tasks.f1='PILS_task_T1';
            % Assigning upper and lower bounds of search space of task 1
            Tasks.L1=-50*ones(1,50);
            Tasks.U1=50*ones(1,50);
            Tasks.L1(1)=0;
            Tasks.U1(1)=1;
            Tasks.type1 = 'circle';
            Tasks.f2='PILS_task_T2';
            % Assigning upper and lower bounds of search space of task 2
            Tasks.L2=-100*ones(1,50);
            Tasks.U2=100*ones(1,50);
            Tasks.L2(1)=0;
            Tasks.U2(1)=1;
            Tasks.type2 = 'circle';
        case 7  %NIHS
            Tasks.f1='NIHS_task_T1';
            % Assigning upper and lower bounds of search space of task 1
            Tasks.L1=-80*ones(1,50);
            Tasks.U1=80*ones(1,50);
            Tasks.L1(1)=0;
            Tasks.U1(1)=1;
            Tasks.type1 = 'circle';
            Tasks.f2='NIHS_task_T2';
            % Assigning upper and lower bounds of search space of task 2
            Tasks.L2=-80*ones(1,50);
            Tasks.U2=80*ones(1,50);
            Tasks.L2(1)=0;
            Tasks.U2(1)=1;
            Tasks.type2 = 'convex';
        case 8  %NIMS
            Tasks.f1='NIMS_task_T1';
            % Assigning upper and lower bounds of search space of task 1
            Tasks.L1=-20*ones(1,20);
            Tasks.U1=20*ones(1,20);
            Tasks.L1(1)=0;
            Tasks.U1(1)=1;
            Tasks.L1(2)=0;
            Tasks.U1(2)=1;
            Tasks.type1 = 'sphere1';
            Tasks.f2='NIMS_task_T2';
            % Assigning upper and lower bounds of search space of task 2
            Tasks.L2=-20*ones(1,20);
            Tasks.U2=20*ones(1,20);
            Tasks.L2(1)=0;
            Tasks.U2(1)=1;
            Tasks.L2(2)=0;
            Tasks.U2(2)=1;
            Tasks.type2 = 'concave';
        case 9  %NILS
            Tasks.f1='NILS_task_T1';
            % Assigning upper and lower bounds of search space of task 1
            Tasks.L1=-50*ones(1,25);
            Tasks.U1=50*ones(1,25);
            Tasks.L1(1)=0;
            Tasks.U1(1)=1;
            Tasks.L1(2)=0;
            Tasks.U1(2)=1;
            Tasks.type1 = 'sphere1';
            Tasks.f2='NILS_task_T2';
            % Assigning upper and lower bounds of search space of task 2
            Tasks.L2=-100*ones(1,25);
            Tasks.U2=100*ones(1,25);
            Tasks.L2(1)=0;
            Tasks.U2(1)=1;
            Tasks.L2(2)=0;
            Tasks.U2(2)=1;
            Tasks.type2 = 'concave';
end