% Note that this trial version of the MO-MFEA (which is based on NSGA-II) handles upto 2 "continuous" multi-objective 
% optimization tasks concurrently. Further, this code is tested for upto 3 
% objective functions per task. 

% Default Parameter Settings and genetic operators provided/implemented herein are in accordance with the paper
% "Multi-Objective Multifactorial Optimization in Evolutionary
% Multitasking" published in IEEE Trans. Cybernetics, 2016. 

% This implementation assumes a simple random-key encoding scheme with a
% straightforward decoding mechanism as described in "Multi-Objective Multifactorial Optimization in Evolutionary
% Multitasking" published in IEEE Trans. Cybernetics, and "Multifactorial
% Evolution: Towards Evolutionary Multitasking", published in IEEE Trans.
% TEVC. More sophisticated unified representation schemes, decoding
% mechanisms, genetic operators, etc., may be implemented in a simple manner for real-world problems
% where relevant domain knowledge is available.

% Note that the mat file M.mat contains a randomly generated rotation matrix of size 9x9. 

% Note that the mat file data.mat contains the Pareto Front of the ZDT4
% family of problems.

% For any bugs identified or future suggestions, please contact Abhishek
% Gupta at abhishekg@ntu.edu.sg
clear all
rmp=0.9; % Random mating probability
gen = 1000; % Maximum Number of generations
muc = 20; % Distribution Index of SBX crossover operator
mum = 20; % Distribution Index of Polynomial Mutation operator
pc = 0.9; % Probability that certain pair of variables are swapped (uniform crossover-like) during SBX crossover. Change to prob_swap = 0.5 for enhanced global search at the cost of high chromosome disruption.
pop1=100; % Population size for task 1
pop2=100; % Population size for task 2
reps = 10;
for index =1:9
    Task = benchmark(index);
    [data_MOMFEA(index),population]  = MOMFEA(Task,pop1,pop2,rmp,gen,muc,mum,pc,reps,index); 
end
save('data_MOMFEA','data_MOMFEA');