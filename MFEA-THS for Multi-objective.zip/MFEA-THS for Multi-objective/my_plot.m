function [] = my_plot(T1_f1,T1_f2,T2_f1,T2_f2)
    clf
    figure(1)
    plot(T1_f1,T1_f2,'.','markersize',10);
    title('Task 1 PF approx.');
    xlabel('Objective f1');
    ylabel('Objective f2');
    figure(2)
    plot(T2_f1,T2_f2,'.','markersize',10);
    title('Task 2 PF approx.');
    xlabel('Objective f1');
    ylabel('Objective f2');
    pause(0.1);
end