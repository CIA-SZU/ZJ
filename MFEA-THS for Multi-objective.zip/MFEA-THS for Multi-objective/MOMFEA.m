% This trial version of the Multi-Objective Multifactorial Evolutionary Algorithm (MO-MFEA: which is based on NSGA-II) has been
% developed to handle only two "continuous" multiobjective problems (or tasks) at a time.
% Each problem may comprise upto three objective functions.
% Generalization to many-tasking can be done based on this framework.
function [data_MOMFEA,population]=MOMFEA(Task,pop1,pop2,rmp,gen,muc,mum,pc,reps,index)  
    tic
    pop = pop1+pop2;
    dim1=length(Task.L1);
    dim2=length(Task.L2);
    dim=max([dim1,dim2]);
    for rep = 1:reps
        bestobj(1) = 9999999999999999999;
        bestobj(2) = 9999999999999999999;
        M1 = ones(1,dim);
        M2 = ones(1,dim);
        for i=1:pop
            population(i)=Chromosome;
            population(i)=initialize(population(i),dim);
            if i<=pop1
                population(i).skill_factor=1;
            else
                population(i).skill_factor=2;
            end
        end    
        for i=1:pop
            population(i)=evaluate(population(i),Task,dim1,dim2);
        end        
        population_T1=population([population.skill_factor]==1);
        population_T2=population([population.skill_factor]==2);
        no_of_objs_T1 = length(population_T1(1).objs_T1);
        no_of_objs_T2 = length(population_T2(1).objs_T2);
        rnvec_T1 = [];
        rnvec_T2 = [];
        for i =1:length(population_T1)
            rnvec_T1 = [rnvec_T1;population_T1(i).rnvec];
        end
        for i =1:length(population_T2)
            rnvec_T2 = [rnvec_T2;population_T2(i).rnvec];
        end
        max_T1 = max(rnvec_T1);
        max_T2 = max(rnvec_T2);
        min_T1 = min(rnvec_T1);
        min_T2 = min(rnvec_T2);
        
        for generation=1:gen
           rndlist=randperm(pop);
           population=population(rndlist);
            generation
            count=1;
            if mod(generation,2) == 0
                a = 0;
            else
                a = 1;
            end
            for i=1:pop/2 
                child(count)=Chromosome;
                child(count+1)=Chromosome;
                p1=i;
                p2=i+1;
                k = 0.5 + 1*rand(1);
                if population(p1).skill_factor==population(p2).skill_factor
                    if rand(1) > a
                        child(count).rnvec=Evolve.crossover(population(p1).rnvec,population(p2).rnvec,muc,dim,pc);
                        child(count+1).rnvec = 1 - child(count).rnvec;
                    elseif population(p1).skill_factor == 1
                        child(count).rnvec=Evolve.crossover(population(p1).rnvec,population(p2).rnvec,muc,dim,pc);
                        child(count+1).rnvec = k*(max_T1+min_T1) - child(count).rnvec;
                    else
                        child(count).rnvec=Evolve.crossover(population(p1).rnvec,population(p2).rnvec,muc,dim,pc);
                        child(count+1).rnvec = k*(max_T2+min_T2) - child(count).rnvec;
                    end 
                    child(count).skill_factor=population(p1).skill_factor;
                    child(count+1).skill_factor=population(p2).skill_factor;
                else
                    if rand(1)<rmp
                        if rand(1) > 0.5
                            if population(p1).skill_factor == 1 && population(p2).skill_factor == 2
                                tmp = population(p1);
                                tmp.rnvec = population(p1).rnvec .* M1;
                                tmp.rnvec(tmp.rnvec>1) = 1;
                                tmp.rnvec(tmp.rnvec<0) = 0;
                                child(count).rnvec = Evolve.crossover(tmp.rnvec,population(p2).rnvec,muc,dim,pc);
                                if rand(1) > a
                                    child(count+1).rnvec = 1 - child(count).rnvec;
                                else
                                    child(count+1).rnvec = k*(max_T2+min_T2) - child(count).rnvec;
                                end
                            else
                                tmp = population(p2);
                                tmp.rnvec = population(p2).rnvec .* M1;
                                tmp.rnvec(tmp.rnvec>1) = 1;
                                tmp.rnvec(tmp.rnvec<0) = 0;
                                child(count).rnvec = Evolve.crossover(population(p1).rnvec,tmp.rnvec,muc,dim,pc);
                                if rand(1) > a
                                    child(count+1).rnvec = 1 - child(count).rnvec;
                                else
                                    child(count+1).rnvec = k*(max_T2+min_T2) - child(count).rnvec;
                                end
                            end
                        else
                            if population(p1).skill_factor == 2 && population(p2).skill_factor == 1
                                tmp = population(p1);
                                tmp.rnvec = population(p1).rnvec .* M2;
                                tmp.rnvec(tmp.rnvec>1) = 1;
                                tmp.rnvec(tmp.rnvec<0) = 0;
                                child(count).rnvec= Evolve.crossover(tmp.rnvec,population(p2).rnvec,muc,dim,pc); 
                                if rand(1) > a
                                    child(count+1).rnvec = 1 - child(count).rnvec;
                                else
                                    child(count+1).rnvec = k*(max_T1+min_T1) - child(count).rnvec;
                                end
                            else
                                tmp = population(p2);
                                tmp.rnvec = population(p2).rnvec .* M2;
                                tmp.rnvec(tmp.rnvec>1) = 1;
                                tmp.rnvec(tmp.rnvec<0) = 0;
                                child(count).rnvec= Evolve.crossover(population(p1).rnvec,tmp.rnvec,muc,dim,pc);
                                if rand(1) > a
                                    child(count+1).rnvec = 1 - child(count).rnvec;
                                else
                                    child(count+1).rnvec = k*(max_T1+min_T1) - child(count).rnvec;
                                end
                            end
                        end
                        child(count).skill_factor=round(rand(1))+1;
                        child(count+1).skill_factor=round(rand(1))+1;
                    else
                        child(count).rnvec = Evolve.mutate(population(p1).rnvec,mum,dim,1/dim);
                        child(count+1).rnvec=Evolve.mutate(population(p2).rnvec,mum,dim,1/dim);
                        child(count).skill_factor=population(p1).skill_factor;
                        child(count+1).skill_factor=population(p2).skill_factor;
                    end
                end
                child(count).rnvec(child(count).rnvec>1)=1;
                child(count).rnvec(child(count).rnvec<0)=0;
                child(count+1).rnvec(child(count+1).rnvec>1)=1;
                child(count+1).rnvec(child(count+1).rnvec<0)=0;
                child(count).rnvec(isnan(child(count).rnvec)) = rand(1);
                child(count+1).rnvec(isnan(child(count+1).rnvec)) = rand(1);
                count=count+2;
            end        
            for i=1:pop
                child(i)=evaluate(child(i),Task,dim1,dim2);
            end
            population=reset(population,pop);
            intpopulation(1:pop)=population;
            intpopulation(pop+1:2*pop)=child;
            intpopulation_T1=intpopulation([intpopulation.skill_factor]==1);
            intpopulation_T2=intpopulation([intpopulation.skill_factor]==2);
            T1_pop=length(intpopulation_T1);
            T2_pop=length(intpopulation_T2);
            pop_objs_T1=[];
            pop_objs_T2=[];
            for i=1:T1_pop
                pop_objs_T1(i,:) = intpopulation_T1(i).objs_T1;
            end
            [frontnumbers, FrontNO1,~] = NDSort(pop_objs_T1,inf);
            for i=1:T1_pop
                intpopulation_T1(i).front = FrontNO1(i);
            end
            [intpopulation_T1,~]=SolutionComparison.diversity(intpopulation_T1,frontnumbers,T1_pop,no_of_objs_T1);
            for i=1:T2_pop
                pop_objs_T2(i,:) = intpopulation_T2(i).objs_T2;
            end
            [frontnumbers, FrontNO2,~] = NDSort(pop_objs_T2,inf);
            for i=1:T2_pop
                intpopulation_T2(i).front = FrontNO2(i);
            end
            [intpopulation_T2,~]=SolutionComparison.diversity(intpopulation_T2,frontnumbers,T2_pop,no_of_objs_T2);
            population(1:pop1) = intpopulation_T1(1:pop1);
            population(pop1+1:pop) = intpopulation_T2(1:pop2);   
            population_T1=population([population.skill_factor]==1);
            population_T2=population([population.skill_factor]==2);
            rnvec_T1 = [];
            rnvec_T2 = [];
            for i =1:length(population_T1)
                rnvec_T1 = [rnvec_T1;population_T1(i).rnvec];
            end
            for i =1:length(population_T2)
                rnvec_T2 = [rnvec_T2;population_T2(i).rnvec];
            end
            max_T1 = max(rnvec_T1);
            max_T2 = max(rnvec_T2);
            min_T1 = min(rnvec_T1);
            min_T2 = min(rnvec_T2);
            [M1,M2] = domain_ad(population);
            % Convergence testing
            if index == 8 || index == 9
                T1_data = vec2mat([population(1:pop1).objs_T1],3);
                T2_data = vec2mat([population(pop1+1:pop).objs_T2],2);
            else
                T1_data = vec2mat([population(1:pop1).objs_T1],2);
                T2_data = vec2mat([population(pop1+1:pop).objs_T2],2);
            end
            t1_IGD = cal_IGD(T1_data,Task.type1);
            if t1_IGD<=bestobj(1)
                bestobj(1)=t1_IGD;
                store(1,generation)= t1_IGD;
            else
                store(1,generation)= store(1,generation-1);
            end
            t2_IGD = cal_IGD(T2_data,Task.type2);
            if t2_IGD<=bestobj(2)
                bestobj(2)=t2_IGD;
                store(2,generation)= t2_IGD;
            else
                store(2,generation)= store(2,generation-1);
            end
            
%             T1_f1=[];
%             T1_f2=[];
%             T2_f1=[];
%             T2_f2=[];
%             for i=1:pop
%                 if population(i).skill_factor==1
%                     T1_f1=[T1_f1,population(i).objs_T1(1)];
%                     T1_f2=[T1_f2,population(i).objs_T1(2)];
%                 elseif population(i).skill_factor==2
%                     T2_f1=[T2_f1,population(i).objs_T2(1)];
%                     T2_f2=[T2_f2,population(i).objs_T2(2)];
%                 end
%             end
%             my_plot(T1_f1,T1_f2,T2_f1,T2_f2);
        end
%         T1_f1=[];
%         T1_f2=[];
%         T2_f1=[];
%         T2_f2=[];
%         for i=1:pop
%             if population(i).skill_factor==1
%                 T1_f1=[T1_f1,population(i).objs_T1(1)];
%                 T1_f2=[T1_f2,population(i).objs_T1(2)];
%             elseif population(i).skill_factor==2
%                 T2_f1=[T2_f1,population(i).objs_T2(1)];
%                 T2_f2=[T2_f2,population(i).objs_T2(2)];
%             end
%         end
%         my_plot(T1_f1,T1_f2,T2_f1,T2_f2);
        IGD1(rep,:) = store(1,:);
        IGD2(rep,:) = store(2,:);
%         if index == 8 || index == 9
%             T1_data = vec2mat([population(1:pop1).objs_T1],3);
%             T2_data = vec2mat([population(pop1+1:pop).objs_T2],2);
%         else
%             T1_data = vec2mat([population(1:pop1).objs_T1],2);
%             T2_data = vec2mat([population(pop1+1:pop).objs_T2],2);
%         end
%         IGD(1,rep) = store(1,:);
%         IGD(2,rep) = store(2,:);
    end
    data_MOMFEA.wall_clock_time = toc;
    data_MOMFEA.IGD1 = IGD1;
    data_MOMFEA.IGD2 = IGD2;
    
%     T1_f1=[];
%     T1_f2=[];
%     T1_f3=[];
%     T2_f1=[];
%     T2_f2=[];
%     T2_f3=[];
%     for i=1:pop
%         if population(i).skill_factor==1
%             if no_of_objs_T1 == 2
%                 T1_f1=[T1_f1,population(i).objs_T1(1)];
%                 T1_f2=[T1_f2,population(i).objs_T1(2)];
%             else
%                 T1_f1=[T1_f1,population(i).objs_T1(1)];
%                 T1_f2=[T1_f2,population(i).objs_T1(2)];
%                 T1_f3=[T1_f3,population(i).objs_T1(3)];
%             end
%         else
%             if no_of_objs_T2 == 2
%                 T2_f1=[T2_f1,population(i).objs_T2(1)];
%                 T2_f2=[T2_f2,population(i).objs_T2(2)];
%             else
%                 T2_f1=[T2_f1,population(i).objs_T2(1)];
%                 T2_f2=[T2_f2,population(i).objs_T2(2)];
%                 T2_f3=[T2_f3,population(i).objs_T2(3)];
%             end
%         end
%     end
%     figure(01)
%     if no_of_objs_T1 == 2
%         plot(T1_f1,T1_f2,'o')
%         title('Task 1 PF approx.')
%         xlabel('Objective f1')
%         ylabel('Objective f2')
%     else
%         plot3(T1_f1,T1_f2,T1_f3,'o')
%     end
%     figure(02)
%     if no_of_objs_T2 == 2
%         plot(T2_f1,T2_f2,'o')
%         title('Task 2 PF approx.')
%         xlabel('Objective f1')
%         ylabel('Objective f2')
%     else
%         plot3(T2_f1,T2_f2,T2_f3,'o')
%     end    
%     figure(03)
%     plot(store(1,:)/max(store(1,:)))
%     title('Task 1 IGD convergence')
%     xlabel('Generations')
%     ylabel('IGD')
%     figure(04)
%     plot(store(2,:)/max(store(2,:)))
%     title('Task 2 IGD convergence')
%     xlabel('Generations')
%     ylabel('IGD')
end