function IGD = cal_IGD(data,type)
    IGD = 0;
    switch(type)
        case 'circle'
            load circle.pf
            %%IGD
%             Distance = min(pdist2(data,circle),[],2);
%             IGD = mean(Distance);
            %%IGD+
            [n,~]=size(circle);
            [popnum,~]=size(data);
            for i=1:popnum   
                hh=repmat(data(i,:),n,1)-circle;
                hh(hh<0)=0;
                c =(sum(hh.^2,2)).^(1/2);
                FF(i,:)=c';
            end
            Distance = min(FF',[],2);
            IGD = mean(Distance);
            %%GD
%              Distance = min(pdist2(data,circle),[],2);
%              IGD = norm(Distance) / length(Distance);
        case 'convex'
            load convex.pf
            %%IGD
%             Distance = min(pdist2(data,convex),[],2);
%             IGD = mean(Distance);
            %%IGD+
            [n,~]=size(convex);
            [popnum,~]=size(data);
            for i=1:popnum   
                hh=repmat(data(i,:),n,1)-convex;
                hh(hh<0)=0;
                c =(sum(hh.^2,2)).^(1/2);
                FF(i,:)=c';
            end
            Distance = min(FF',[],2);
            IGD = mean(Distance);
            %%GD
%              Distance = min(pdist2(data,convex),[],2);
%              IGD = norm(Distance) / length(Distance);
        case 'concave'
            load concave.pf
            %%IGD
%             Distance = min(pdist2(data,concave),[],2);
%             IGD = mean(Distance);
            %%IGD+
            [n,~]=size(concave);
            [popnum,~]=size(data);
            for i=1:popnum   
                hh=repmat(data(i,:),n,1)-concave;
                hh(hh<0)=0;
                c =(sum(hh.^2,2)).^(1/2);
                FF(i,:)=c';
            end
            Distance = min(FF',[],2);
            IGD = mean(Distance);
%               %%GD
%              Distance = min(pdist2(data,concave),[],2);
%              IGD = norm(Distance) / length(Distance);
        case 'sphere1'
            load sphere1.pf
            %%IGD
%             Distance = min(pdist2(data,sphere1),[],2);
%             IGD = mean(Distance);
            %%IGD+
            [n,~]=size(sphere1);
            [popnum,~]=size(data);
            for i=1:popnum   
                hh=repmat(data(i,:),n,1)-sphere1;
                hh(hh<0)=0;
                c =(sum(hh.^2,2)).^(1/2);
                FF(i,:)=c';
            end
            Distance = min(FF',[],2);
            IGD = mean(Distance);
             %%GD
%              Distance = min(pdist2(data,sphere1),[],2);
%              IGD = norm(Distance) / length(Distance);
    end
end