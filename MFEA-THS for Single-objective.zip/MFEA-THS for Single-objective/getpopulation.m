function population = getpopulation(T_population,no_of_tasks)
    num = length(T_population);
    factorial_cost=zeros(1,num);
    for i=1:num
        factorial_cost(i)=T_population(i).factorial_costs(no_of_tasks);
    end
    [xxx,y]=sort(factorial_cost);
    T_population = T_population(y);
    population = T_population(1:num/2);
end