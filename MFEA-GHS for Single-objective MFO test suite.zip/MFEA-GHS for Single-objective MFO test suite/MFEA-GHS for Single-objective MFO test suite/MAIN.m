clear all
pop_M=100; % population size 100
gen=2000; % generation count 2000
p_il = 0; % probability of individual learning (BFGA quasi-Newton Algorithm) --> Indiviudal Learning is an IMPORTANT component of the MFEA.
rmp=0.7;% random mating probability
reps = 30; % repetitions 20
for index =1:9
    Tasks = benchmark(index);
    MFEA_GHS_data(index)=MFEA_GHS(Tasks,pop_M,gen,rmp,p_il,reps);  
end
save('result.mat','MFEA_GHS_data');
